// PYNQ-Z2 FPGA Top-Level Module with Clock Divider and Debouncers
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Target Board: TUL PYNQ-Z2 (Xilinx Zynq-7000 XC7Z020-1CLG400C)

`timescale 1ns / 1ps

module fpga_top (
    input  wire        sysclk,       // 125 MHz onboard clock
    input  wire [3:0]  btn,          // btn[0]: Reset, btn[1]: Load
    input  wire [1:0]  sw,           // sw[1:0]: Mode / Test select
    input  wire [15:0] dip_sw,       // 16 DIP switches (via PMOD / Arduino headers)
    output wire [3:0]  led,          // Onboard User LEDs (out[3:0])
    output wire [7:0]  ext_led,      // External PMOD LEDs (out[7:0])
    output wire        led_carry,    // Carry LED (out[8])
    output wire [5:0]  led_flags,    // Status flag LEDs (out[14:9])
    output reg  [2:0]  rgbled0,      // RGB LED 0: Status
    output reg  [2:0]  rgbled1       // RGB LED 1: Comparator
);

    // Clock Generation: Divide 125 MHz down to 20 MHz
    // 125 MHz / 20 MHz = 6.25 (using 3-stage fractional / counter divider or PLL)
    // For integer simulation / synthesis: 125MHz / 6 ~ 20.83 MHz, or clean synchronous tick
    reg [2:0] clk_div_cnt = 3'b000;
    reg       clk_20mhz   = 1'b0;

    always @(posedge sysclk) begin
        if (clk_div_cnt == 3'd2) begin
            clk_div_cnt <= 3'd0;
            clk_20mhz   <= ~clk_20mhz; // ~20.8 MHz clock
        end else begin
            clk_div_cnt <= clk_div_cnt + 1'b1;
        end
    end

    // Button Debounce and Synchronizer for Reset and Load
    reg [19:0] debounce_cnt = 20'd0;
    reg [1:0]  btn_sync0 = 2'b00;
    reg [1:0]  btn_sync1 = 2'b00;
    reg [1:0]  btn_debounced = 2'b00;
    reg [1:0]  btn_prev = 2'b00;
    wire       rst_pulse;
    wire       load_pulse;

    always @(posedge sysclk) begin
        btn_sync0 <= btn[1:0];
        btn_sync1 <= btn_sync0;
        debounce_cnt <= debounce_cnt + 1'b1;
        if (debounce_cnt == 20'hFFFFF) begin
            btn_debounced <= btn_sync1;
        end
        btn_prev <= btn_debounced;
    end

    assign rst_pulse  = btn_debounced[0];
    assign load_pulse = btn_debounced[1] & ~btn_prev[1]; // Single cycle strobe on press

    // Select input switches (onboard sw + dip_sw)
    wire [15:0] proc_in;
    assign proc_in = dip_sw;

    // Core Output Wire
    wire [15:0] proc_out;

    // Instantiate Parameterized Educational Processor Core
    top_edu_processor #(
        .CLK_FREQ_HZ(20_000_000),
        .CLK_PERIOD_NS(50)
    ) u_top_proc (
        .in(proc_in),
        .load(load_pulse | sw[0]), // Load on button press or switch enable
        .clk(clk_20mhz),
        .rst(rst_pulse),
        .out(proc_out)
    );

    // Map outputs to board LEDs
    assign led       = proc_out[3:0]; // Onboard LEDs show lower 4 bits
    assign ext_led   = proc_out[7:0]; // Full 8-bit result on external LEDs
    assign led_carry = proc_out[8];   // Carry flag LED
    assign led_flags = proc_out[14:9];// Zero, Sign, Parity, Overflow, Comp GT, Comp EQ

    // RGB LED Mapping
    always @(*) begin
        // RGBLED0: [R]=Overflow, [G]=Zero, [B]=Carry
        rgbled0 = {proc_out[12], proc_out[9], proc_out[8]};
        // RGBLED1: [R]=Comp LT, [G]=Comp EQ, [B]=Comp GT
        rgbled1 = {proc_out[14], proc_out[14], proc_out[13]};
    end

endmodule
