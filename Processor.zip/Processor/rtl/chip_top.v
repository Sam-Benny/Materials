// SCL 180nm ASIC Top-Level Padframe Module
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Uses SCL 180nm standard IO pad cells (pc3d01, pc3o01, pc3c04, and power pads)

`timescale 1ns / 1ps

module chip_top (
    in,
    out,
    clk,
    rst,
    load
);

    input  [15:0] in;
    output [14:0] out; // out[7:0]=Result, out[8]=Carry, out[14:9]=Flags
    input         clk;
    input         rst;
    input         load;

    // Internal core signal interconnects
    wire [15:0] in_core;
    wire [15:0] out_core;
    wire        clk_pad_raw;
    wire        clk_core;
    wire        rst_core;
    wire        load_core;

    // Power rail wires (for LVS and structural netlist)
    wire VDD, VSS, VSSO, VDDO;

    // Instantiate Core Top Module
    top_edu_processor #(
        .CLK_FREQ_HZ(20_000_000),
        .CLK_PERIOD_NS(50)
    ) u_core_top (
        .in(in_core),
        .load(load_core),
        .clk(clk_core),
        .rst(rst_core),
        .out(out_core)
    );

    assign out[7:0]  = out_core[7:0];  // 8-bit Result LEDs
    assign out[8]    = out_core[8];    // Carry LED
    assign out[14:9] = out_core[14:9]; // Status flags

    ////////////////////////////////////////////////////////////////////////////////
    // LEFT SIDE PADS (12 Slots: in[0..7] + 4 Power Pads)
    ////////////////////////////////////////////////////////////////////////////////
    pv0a   pv0a_L (.VSSO(VSSO));
    pvda   pvda_L (.VDDO(VDDO));
    pc3d01 I0     (.PAD(in[0]), .CIN(in_core[0])); // mem_addr[0]
    pc3d01 I1     (.PAD(in[1]), .CIN(in_core[1])); // mem_addr[1]
    pc3d01 I2     (.PAD(in[2]), .CIN(in_core[2])); // mem_addr[2]
    pc3d01 I3     (.PAD(in[3]), .CIN(in_core[3])); // mem_addr[3]
    pv0c   pv0c_L (.VSSC(VSS));
    pvdc   pvdc_L (.VDDC(VDD));
    pc3d01 I4     (.PAD(in[4]), .CIN(in_core[4])); // rd2[0]
    pc3d01 I5     (.PAD(in[5]), .CIN(in_core[5])); // rd2[1]
    pc3d01 I6     (.PAD(in[6]), .CIN(in_core[6])); // rd2[2]
    pc3d01 I7     (.PAD(in[7]), .CIN(in_core[7])); // rd2[3]

    ////////////////////////////////////////////////////////////////////////////////
    // TOP SIDE PADS (12 Slots: in[8..15] + CLK + CLK_BUF + 2 Power Pads)
    ////////////////////////////////////////////////////////////////////////////////
    pc3d01 I8      (.PAD(in[8]),  .CIN(in_core[8]));  // rd1[0]
    pc3d01 I9      (.PAD(in[9]),  .CIN(in_core[9]));  // rd1[1]
    pc3d01 I10     (.PAD(in[10]), .CIN(in_core[10])); // rd1[2]
    pc3d01 I11     (.PAD(in[11]), .CIN(in_core[11])); // rd1[3]
    pvdi   pvdi_T  (.VDD(VDD));
    pv0i   pv0i_T  (.VSS(VSS));
    pc3d01 I12     (.PAD(in[12]), .CIN(in_core[12])); // opcode[0]
    pc3d01 I13     (.PAD(in[13]), .CIN(in_core[13])); // opcode[1]
    pc3d01 I14     (.PAD(in[14]), .CIN(in_core[14])); // opcode[2]
    pc3d01 I15     (.PAD(in[15]), .CIN(in_core[15])); // opcode[3]
    pc3c04 CLK_BUF (.CCLK(clk_pad_raw), .CP(clk_core));
    pc3d01 CLK_PAD (.PAD(clk),    .CIN(clk_pad_raw));

    ////////////////////////////////////////////////////////////////////////////////
    // RIGHT SIDE PADS (12 Slots: out[8..14] + LOAD + RST + 3 Power Pads)
    ////////////////////////////////////////////////////////////////////////////////
    pc3o01 O8       (.PAD(out[8]),  .I(out_core[8]));  // Carry
    pc3o01 O9       (.PAD(out[9]),  .I(out_core[9]));  // Zero Flag
    pc3o01 O10      (.PAD(out[10]), .I(out_core[10])); // Sign Flag
    pc3o01 O11      (.PAD(out[11]), .I(out_core[11])); // Parity Flag
    pv0f   pv0f_R   (.VSS(VSS));
    pc3o01 O12      (.PAD(out[12]), .I(out_core[12])); // Overflow Flag
    pc3o01 O13      (.PAD(out[13]), .I(out_core[13])); // Comp GT
    pc3o01 O14      (.PAD(out[14]), .I(out_core[14])); // Comp EQ/LT
    pc3d01 LOAD_PAD (.PAD(load),    .CIN(load_core));  // Load Input Strobe
    pv0c   pv0c_R   (.VSSC(VSS));
    pvdc   pvdc_R   (.VDDC(VDD));
    pc3d01 RST_PAD  (.PAD(rst),     .CIN(rst_core));   // Reset Input

    ////////////////////////////////////////////////////////////////////////////////
    // BOTTOM SIDE PADS (12 Slots: out[0..7] + 4 Power Pads)
    ////////////////////////////////////////////////////////////////////////////////
    pv0a   pv0a_B (.VSSO(VSSO));
    pvda   pvda_B (.VDDO(VDDO));
    pc3o01 O0     (.PAD(out[0]), .I(out_core[0])); // Result[0] (LSB)
    pc3o01 O1     (.PAD(out[1]), .I(out_core[1])); // Result[1]
    pc3o01 O2     (.PAD(out[2]), .I(out_core[2])); // Result[2]
    pc3o01 O3     (.PAD(out[3]), .I(out_core[3])); // Result[3]
    pv0i   pv0i_B (.VSS(VSS));
    pvdi   pvdi_B (.VDD(VDD));
    pc3o01 O4     (.PAD(out[4]), .I(out_core[4])); // Result[4]
    pc3o01 O5     (.PAD(out[5]), .I(out_core[5])); // Result[5]
    pc3o01 O6     (.PAD(out[6]), .I(out_core[6])); // Result[6]
    pc3o01 O7     (.PAD(out[7]), .I(out_core[7])); // Result[7] (MSB)

endmodule
