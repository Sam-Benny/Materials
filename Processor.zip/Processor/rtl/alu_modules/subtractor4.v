// 4-bit Binary Subtractor with Borrow Out
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)

`timescale 1ns / 1ps

module subtractor4 (
    input  wire [3:0] a,
    input  wire [3:0] b,
    output wire [3:0] diff,
    output wire       borrow
);

    wire [4:0] full_diff;

    assign full_diff = {1'b0, a} - {1'b0, b};
    assign diff      = full_diff[3:0];
    assign borrow    = (a < b) ? 1'b1 : 1'b0;

endmodule
