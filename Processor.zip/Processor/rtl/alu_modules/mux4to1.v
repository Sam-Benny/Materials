// 4-to-1 Multiplexer
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// rd1[3:0] provides 4 data input lines; rd2[1:0] provides 2 select lines.

`timescale 1ns / 1ps

module mux4to1 (
    input  wire [3:0] in_data, // rd1[3:0] = {in3, in2, in1, in0}
    input  wire [1:0] sel,     // rd2[1:0] = in[5:4] (in[7:6] ignored)
    output reg        out_bit  // 1-bit multiplexer output
);

    always @(*) begin
        case (sel)
            2'b00:   out_bit = in_data[0];
            2'b01:   out_bit = in_data[1];
            2'b10:   out_bit = in_data[2];
            2'b11:   out_bit = in_data[3];
            default: out_bit = 1'b0;
        endcase
    end

endmodule
