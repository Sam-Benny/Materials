// 4-bit Even Parity Generator
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Computes even parity on 4-bit input rd1[3:0].

`timescale 1ns / 1ps

module parity_gen (
    input  wire [3:0] in,       // 4-bit input rd1[3:0]
    output wire       parity,   // Even parity bit = ^in (1 if odd number of 1s, making total even)
    output wire [4:0] out_frame // 5-bit framed word: {in[3:0], parity}
);

    assign parity    = ^in;
    assign out_frame = {in, ^in};

endmodule
