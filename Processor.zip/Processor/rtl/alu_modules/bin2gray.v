// 4-bit Binary to Gray Code Converter
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Converts 4-bit binary input rd1[3:0] to Gray code.

`timescale 1ns / 1ps

module bin2gray (
    input  wire [3:0] bin,   // 4-bit binary input (from rd1)
    output wire [3:0] gray   // 4-bit Gray code output
);

    assign gray = bin ^ (bin >> 1);

endmodule
