// 4-bit Logic Unit (AND, OR, XOR)
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)

`timescale 1ns / 1ps

module logic_unit (
    input  wire [3:0] a,
    input  wire [3:0] b,
    output wire [3:0] and_out,
    output wire [3:0] or_out,
    output wire [3:0] xor_out
);

    assign and_out = a & b;
    assign or_out  = a | b;
    assign xor_out = a ^ b;

endmodule
