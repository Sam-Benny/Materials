// 16x4-bit Synchronous/Asynchronous Read Data Memory
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Depth = 16 words, Width = 4 bits

`timescale 1ns / 1ps

module data_memory (
    input  wire       clk,
    input  wire       rst,
    input  wire       we,        // Write enable
    input  wire [3:0] addr,      // 4-bit memory address (0 to 15)
    input  wire [3:0] din,       // 4-bit data in
    output wire [3:0] dout       // 4-bit data out
);

    reg [3:0] mem [0:15];
    integer i;

    // Asynchronous read for combinatorial decode or registered read
    assign dout = mem[addr];

    always @(posedge clk) begin
        if (rst) begin
            // Educational default initialization
            mem[0]  <= 4'h0;
            mem[1]  <= 4'h1;
            mem[2]  <= 4'hA;
            mem[3]  <= 4'h5;
            mem[4]  <= 4'h3;
            mem[5]  <= 4'h7;
            mem[6]  <= 4'hE;
            mem[7]  <= 4'h9;
            mem[8]  <= 4'h8;
            mem[9]  <= 4'h4;
            mem[10] <= 4'hB;
            mem[11] <= 4'hC;
            mem[12] <= 4'hD;
            mem[13] <= 4'h2;
            mem[14] <= 4'h6;
            mem[15] <= 4'hF;
        end else if (we) begin
            mem[addr] <= din;
        end
    end

endmodule
