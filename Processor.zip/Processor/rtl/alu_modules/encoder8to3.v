// 8-to-3 Priority Encoder
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Encodes the highest active bit index of the 8-bit input {rd1, rd2} to 3-bit binary code.

`timescale 1ns / 1ps

module encoder8to3 (
    input  wire [7:0] in,      // {rd1[3:0], rd2[3:0]}
    output reg  [2:0] code,    // 3-bit encoded value (0 to 7)
    output wire       valid    // High when at least one input bit is active
);

    assign valid = |in;

    always @(*) begin
        if (in[7])      code = 3'b111;
        else if (in[6]) code = 3'b110;
        else if (in[5]) code = 3'b101;
        else if (in[4]) code = 3'b100;
        else if (in[3]) code = 3'b011;
        else if (in[2]) code = 3'b010;
        else if (in[1]) code = 3'b001;
        else if (in[0]) code = 3'b000;
        else            code = 3'b000;
    end

endmodule
