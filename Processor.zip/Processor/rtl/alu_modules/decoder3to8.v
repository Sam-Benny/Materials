// 3-to-8 One-Hot Decoder
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Takes 3-bit input from rd1[2:0] (bits [10:8] of input word) and drives 8-bit one-hot output.

`timescale 1ns / 1ps

module decoder3to8 (
    input  wire [2:0] in,      // rd1[2:0] = in[10:8]
    input  wire       en,      // Enable signal (active high)
    output wire [7:0] out      // 8-bit one-hot output
);

    assign out = en ? (8'b00000001 << in) : 8'b00000000;

endmodule
