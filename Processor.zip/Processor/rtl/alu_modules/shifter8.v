// 8-bit Shifter and Rotator Unit
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Supports Logical Shift Right, Logical Shift Left, and Rotate on 8-bit operand {rd1, rd2}.

`timescale 1ns / 1ps

module shifter8 (
    input  wire [7:0] in,       // 8-bit operand {rd1[3:0], rd2[3:0]}
    input  wire [2:0] shamt,    // Shift amount (from mem_addr[2:0], default 1 if 0)
    input  wire [1:0] mode,     // 2'b00: Shift Right, 2'b01: Shift Left, 2'b10: Rotate Right, 2'b11: Rotate Left
    output reg  [7:0] out,      // 8-bit result
    output reg        cout      // Carry out (shifted out bit)
);

    wire [2:0] eff_shamt;
    assign eff_shamt = (shamt == 3'b000) ? 3'b001 : shamt;

    always @(*) begin
        case (mode)
            2'b00: begin // Logical Shift Right (SHR)
                out  = in >> eff_shamt;
                cout = in[eff_shamt - 1];
            end
            2'b01: begin // Logical Shift Left (SHL)
                out  = in << eff_shamt;
                cout = in[8 - eff_shamt];
            end
            2'b10: begin // Circular Rotate Right (ROR)
                out  = (in >> eff_shamt) | (in << (8 - eff_shamt));
                cout = 1'b0;
            end
            2'b11: begin // Circular Rotate Left (ROL)
                out  = (in << eff_shamt) | (in >> (8 - eff_shamt));
                cout = 1'b0;
            end
            default: begin
                out  = in;
                cout = 1'b0;
            end
        endcase
    end

endmodule
