// 4-bit Magnitude Comparator
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Compares rd1[3:0] and rd2[3:0]:
// if rd1 > rd2: gt = 1 (output[0])
// if rd1 == rd2: eq = 1 (output[1])
// if rd1 < rd2: lt = 1 (output[2])

`timescale 1ns / 1ps

module comparator4 (
    input  wire [3:0] a,    // rd1[3:0]
    input  wire [3:0] b,    // rd2[3:0]
    output wire       gt,   // Greater than: a > b
    output wire       eq,   // Equal to:     a == b
    output wire       lt,   // Less than:    a < b
    output wire [2:0] comp_bus // {lt, eq, gt}
);

    assign gt = (a > b)  ? 1'b1 : 1'b0;
    assign eq = (a == b) ? 1'b1 : 1'b0;
    assign lt = (a < b)  ? 1'b1 : 1'b0;

    assign comp_bus = {lt, eq, gt}; // [0]=gt, [1]=eq, [2]=lt

endmodule
