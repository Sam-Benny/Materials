// 8-bit Two's Complement Unit
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Computes 2's complement of 8-bit input {rd1[3:0], rd2[3:0]}.

`timescale 1ns / 1ps

module twos_complement8 (
    input  wire [7:0] in,   // 8-bit operand {rd1[3:0], rd2[3:0]}
    output wire [7:0] out   // 8-bit 2's complement result: ~in + 1
);

    assign out = ~in + 8'b00000001;

endmodule
