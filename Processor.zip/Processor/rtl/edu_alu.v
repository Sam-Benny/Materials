// Unified Arithmetic and Logic Unit (ALU)
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Decodes 4-bit opcode and multiplexes results from dedicated execution submodules.

`timescale 1ns / 1ps

module edu_alu (
    input  wire [3:0] opcode,        // 4-bit opcode [15:12]
    input  wire [3:0] rd1,           // 4-bit operand 1 [11:8]
    input  wire [3:0] rd2,           // 4-bit operand 2 [7:4]
    input  wire [3:0] mem_addr,      // 4-bit memory address [3:0]
    input  wire [3:0] mem_dout,      // 4-bit memory data
    output reg  [7:0] result,        // 8-bit output result
    output reg        carry,         // Carry / Borrow / Status out
    output wire       zero,          // Zero flag
    output wire       sign,          // Sign (MSB) flag
    output wire       parity,        // Result parity flag (even parity of result)
    output wire       overflow,      // Overflow flag
    output wire       comp_gt,       // Comparator Greater Than
    output wire       comp_eq,       // Comparator Equal
    output wire       comp_lt        // Comparator Less Than
);

    // Submodule interconnect wires
    wire [3:0] add_sum;
    wire       add_cout;
    wire [3:0] sub_diff;
    wire       sub_borrow;
    wire [3:0] and_out;
    wire [3:0] or_out;
    wire [3:0] xor_out;
    wire [2:0] enc_code;
    wire       enc_valid;
    wire [7:0] dec_out;
    wire       mux_out;
    wire [7:0] shr_out;
    wire       shr_cout;
    wire [7:0] shl_out;
    wire       shl_cout;
    wire [7:0] rot_out;
    wire       rot_cout;
    wire [7:0] twos_out;
    wire [3:0] gray_out;
    wire       par_bit;
    wire [4:0] par_frame;

    wire [7:0] op8;
    assign op8 = {rd1, rd2}; // 8-bit concatenated operand

    // Instantiate Submodules
    adder4 u_adder4 (
        .a(rd1),
        .b(rd2),
        .cin(1'b0),
        .sum(add_sum),
        .cout(add_cout)
    );

    subtractor4 u_sub4 (
        .a(rd1),
        .b(rd2),
        .diff(sub_diff),
        .borrow(sub_borrow)
    );

    logic_unit u_logic (
        .a(rd1),
        .b(rd2),
        .and_out(and_out),
        .or_out(or_out),
        .xor_out(xor_out)
    );

    encoder8to3 u_enc (
        .in(op8),
        .code(enc_code),
        .valid(enc_valid)
    );

    decoder3to8 u_dec (
        .in(rd1[2:0]),
        .en(1'b1),
        .out(dec_out)
    );

    mux4to1 u_mux (
        .in_data(rd1),
        .sel(rd2[1:0]),
        .out_bit(mux_out)
    );

    shifter8 u_shifter (
        .in(op8),
        .shamt(mem_addr[2:0]),
        .mode(opcode[1:0]), // 00: SHR, 01: SHL, 10: ROT
        .out(shr_out),
        .cout(shr_cout)
    );

    shifter8 u_shifter_l (
        .in(op8),
        .shamt(mem_addr[2:0]),
        .mode(2'b01), // SHL
        .out(shl_out),
        .cout(shl_cout)
    );

    shifter8 u_shifter_rot (
        .in(op8),
        .shamt(mem_addr[2:0]),
        .mode(2'b10), // Rotate Right
        .out(rot_out),
        .cout(rot_cout)
    );

    twos_complement8 u_twos (
        .in(op8),
        .out(twos_out)
    );

    bin2gray u_b2g (
        .bin(rd1),
        .gray(gray_out)
    );

    parity_gen u_par (
        .in(rd1),
        .parity(par_bit),
        .out_frame(par_frame)
    );

    comparator4 u_comp (
        .a(rd1),
        .b(rd2),
        .gt(comp_gt),
        .eq(comp_eq),
        .lt(comp_lt),
        .comp_bus()
    );

    // Opcode Decoding & Multiplexing
    always @(*) begin
        case (opcode)
            4'b0000: begin // 0000: Memory Read
                result = {4'b0000, mem_dout};
                carry  = 1'b0;
            end
            4'b0001: begin // 0001: 4-bit Adder
                result = {4'b0000, add_sum};
                carry  = add_cout;
            end
            4'b0010: begin // 0010: 4-bit Subtractor
                result = {4'b0000, sub_diff};
                carry  = sub_borrow;
            end
            4'b0011: begin // 0011: Bitwise AND
                result = {4'b0000, and_out};
                carry  = 1'b0;
            end
            4'b0100: begin // 0100: Bitwise OR
                result = {4'b0000, or_out};
                carry  = 1'b0;
            end
            4'b0101: begin // 0101: Bitwise XOR
                result = {4'b0000, xor_out};
                carry  = 1'b0;
            end
            4'b0110: begin // 0110: 8-to-3 Priority Encoder
                result = {5'b00000, enc_code};
                carry  = enc_valid;
            end
            4'b0111: begin // 0111: 3-to-8 Decoder
                result = dec_out;
                carry  = 1'b0;
            end
            4'b1000: begin // 1000: 4x1 Multiplexer
                result = {7'b0000000, mux_out};
                carry  = 1'b0;
            end
            4'b1001: begin // 1001: Shift Right
                result = shr_out;
                carry  = shr_cout;
            end
            4'b1010: begin // 1010: Shift Left
                result = shl_out;
                carry  = shl_cout;
            end
            4'b1011: begin // 1011: Rotate
                result = rot_out;
                carry  = 1'b0;
            end
            4'b1100: begin // 1100: 2's Complement
                result = twos_out;
                carry  = 1'b0;
            end
            4'b1101: begin // 1101: Binary to Gray
                result = {4'b0000, gray_out};
                carry  = 1'b0;
            end
            4'b1110: begin // 1110: Even Parity Generator
                result = {3'b000, par_frame}; // {rd1[3:0], parity_bit}
                carry  = par_bit;
            end
            4'b1111: begin // 1111: 4-bit Comparator
                result = {5'b00000, comp_lt, comp_eq, comp_gt};
                carry  = 1'b0;
            end
            default: begin
                result = 8'b00000000;
                carry  = 1'b0;
            end
        endcase
    end

    // Flags generation
    assign zero     = (result == 8'b00000000);
    assign sign     = result[7];
    assign parity   = ~^result; // 1 if even parity of 8-bit result
    assign overflow = (opcode == 4'b0001) ? add_cout :
                      (opcode == 4'b0010) ? sub_borrow : 1'b0;

endmodule
