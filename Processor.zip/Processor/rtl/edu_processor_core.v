// Educational Digital Processor Core
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Features: 16-bit input latch, instruction decoder, 16x4-bit data memory,
// unified ALU, output registers, and comprehensive status flag generation.

`timescale 1ns / 1ps

module edu_processor_core (
    input  wire        clk,
    input  wire        rst,
    input  wire        load,
    input  wire [15:0] in,
    output reg  [15:0] out
);

    // Latched Instruction Registers
    reg [3:0] opcode_reg;
    reg [3:0] rd1_reg;
    reg [3:0] rd2_reg;
    reg [3:0] mem_addr_reg;
    reg       exec_valid;

    // Memory Wires
    wire [3:0] mem_dout;

    // ALU Wires
    wire [7:0] alu_result;
    wire       alu_carry;
    wire       alu_zero;
    wire       alu_sign;
    wire       alu_parity;
    wire       alu_overflow;
    wire       alu_gt;
    wire       alu_eq;
    wire       alu_lt;

    // Data Memory Instance (16x4-bit)
    data_memory u_data_mem (
        .clk(clk),
        .rst(rst),
        .we(1'b0), // Read-only for educational kit execution (can be enabled if needed)
        .addr(mem_addr_reg),
        .din(rd1_reg),
        .dout(mem_dout)
    );

    // Unified ALU Instance
    edu_alu u_alu (
        .opcode(opcode_reg),
        .rd1(rd1_reg),
        .rd2(rd2_reg),
        .mem_addr(mem_addr_reg),
        .mem_dout(mem_dout),
        .result(alu_result),
        .carry(alu_carry),
        .zero(alu_zero),
        .sign(alu_sign),
        .parity(alu_parity),
        .overflow(alu_overflow),
        .comp_gt(alu_gt),
        .comp_eq(alu_eq),
        .comp_lt(alu_lt)
    );

    // Sequential Process: Latch inputs on load, execute & register output
    always @(posedge clk) begin
        if (rst) begin
            opcode_reg   <= 4'b0000;
            rd1_reg      <= 4'b0000;
            rd2_reg      <= 4'b0000;
            mem_addr_reg <= 4'b0000;
            exec_valid   <= 1'b0;
            out          <= 16'h0000;
        end else if (load) begin
            // Latch 16-bit input word
            opcode_reg   <= in[15:12];
            rd1_reg      <= in[11:8];
            rd2_reg      <= in[7:4];
            mem_addr_reg <= in[3:0];
            exec_valid   <= 1'b1;

            // Direct registered output update from combinatorial ALU
            out[7:0]     <= alu_result;
            out[8]       <= alu_carry;
            out[9]       <= alu_zero;
            out[10]      <= alu_sign;
            out[11]      <= alu_parity;
            out[12]      <= alu_overflow;
            out[13]      <= alu_gt;
            out[14]      <= alu_eq;
            out[15]      <= alu_lt;
        end else if (exec_valid) begin
            // Maintain stable output and refresh flags from latched registers
            out[7:0]     <= alu_result;
            out[8]       <= alu_carry;
            out[9]       <= alu_zero;
            out[10]      <= alu_sign;
            out[11]      <= alu_parity;
            out[12]      <= alu_overflow;
            out[13]      <= alu_gt;
            out[14]      <= alu_eq;
            out[15]      <= alu_lt;
        end
    end

endmodule
