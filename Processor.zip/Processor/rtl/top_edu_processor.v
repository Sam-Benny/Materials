// Top-Level Educational Digital Processor Core
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Parameterized Clock Frequency (default: 20 MHz / 50ns period)

`timescale 1ns / 1ps

module top_edu_processor #(
    parameter integer CLK_FREQ_HZ   = 20_000_000, // 20 MHz Default Clock Frequency
    parameter integer CLK_PERIOD_NS = 50          // 50 ns Clock Period
)(
    input  wire [15:0] in,   // [15:12]=Opcode, [11:8]=RD1, [7:4]=RD2, [3:0]=MemAddr
    input  wire        load, // Load input strobe / DIP switch trigger
    input  wire        clk,  // 20 MHz System Clock
    input  wire        rst,  // Synchronous Reset
    output wire [15:0] out   // [7:0]=Result LEDs, [8]=Carry, [15:9]=Status Flags
);

    // Instantiate Educational Processor Core
    edu_processor_core u_core (
        .clk(clk),
        .rst(rst),
        .load(load),
        .in(in),
        .out(out)
    );

endmodule
