#!/bin/bash
# Script to run all testbenches for Educational Digital Processor

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"

mkdir -p sim_build

echo "================================================================"
echo " 1. RUNNING ALL SUBMODULE UNIT TESTBENCHES                     "
echo "================================================================"

SUBMODULES=(
    "tb_adder4 rtl/alu_modules/adder4.v"
    "tb_subtractor4 rtl/alu_modules/subtractor4.v"
    "tb_logic_unit rtl/alu_modules/logic_unit.v"
    "tb_encoder8to3 rtl/alu_modules/encoder8to3.v"
    "tb_decoder3to8 rtl/alu_modules/decoder3to8.v"
    "tb_mux4to1 rtl/alu_modules/mux4to1.v"
    "tb_shifter8 rtl/alu_modules/shifter8.v"
    "tb_twos_complement8 rtl/alu_modules/twos_complement8.v"
    "tb_bin2gray rtl/alu_modules/bin2gray.v"
    "tb_parity_gen rtl/alu_modules/parity_gen.v"
    "tb_comparator4 rtl/alu_modules/comparator4.v"
    "tb_data_memory rtl/alu_modules/data_memory.v"
)

for test in "${SUBMODULES[@]}"; do
    tb=$(echo $test | cut -d' ' -f1)
    src=$(echo $test | cut -d' ' -f2)
    echo "--------------------------------------------------------"
    echo "Simulating $tb ($src)..."
    iverilog -o "sim_build/${tb}" "tb/${tb}.v" "$src"
    vvp "sim_build/${tb}"
done

echo ""
echo "================================================================"
echo " 2. RUNNING PROCESSOR CORE COMPREHENSIVE TESTBENCH             "
echo "================================================================"
iverilog -o sim_build/sim_core \
    tb/tb_edu_processor_core.v \
    rtl/top_edu_processor.v \
    rtl/edu_processor_core.v \
    rtl/edu_alu.v \
    rtl/alu_modules/*.v
vvp sim_build/sim_core

echo ""
echo "================================================================"
echo " 3. RUNNING ASIC CHIP TOP (48-PAD FRAME) TESTBENCH              "
echo "================================================================"
iverilog -o sim_build/sim_chip \
    tb/tb_chip_top.v \
    rtl/chip_top.v \
    rtl/top_edu_processor.v \
    rtl/edu_processor_core.v \
    rtl/edu_alu.v \
    rtl/alu_modules/*.v
vvp sim_build/sim_chip

echo ""
echo "================================================================"
echo " 4. RUNNING PYNQ-Z2 FPGA TOP TESTBENCH                          "
echo "================================================================"
iverilog -o sim_build/sim_fpga \
    tb/tb_fpga_top.v \
    rtl/fpga_top.v \
    rtl/top_edu_processor.v \
    rtl/edu_processor_core.v \
    rtl/edu_alu.v \
    rtl/alu_modules/*.v
vvp sim_build/sim_fpga

echo ""
echo "================================================================"
echo " ALL TESTBENCHES COMPLETED SUCCESSFULLY!                        "
echo "================================================================"
