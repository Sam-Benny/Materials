(globals
	version = 3
	io_order = clockwise
	space = 90
	total_edge = 5
)
(iopad

     (topleft   (inst name="CornerCell2" cell=pfrelr offset=0 orientation = R180 place_status = fixed))

     (left      (inst name="pv0a_L"   cell=pv0a   place_status = fixed)
                (inst name="pvda_L"   cell=pvda   place_status = fixed)
                (inst name="I0"       cell=pc3d01 place_status = fixed)
                (inst name="I1"       cell=pc3d01 place_status = fixed)
                (inst name="I2"       cell=pc3d01 place_status = fixed)
                (inst name="I3"       cell=pc3d01 place_status = fixed)
                (inst name="pv0c_L"   cell=pv0c   place_status = fixed)
                (inst name="pvdc_L"   cell=pvdc   place_status = fixed)
                (inst name="I4"       cell=pc3d01 place_status = fixed)
                (inst name="I5"       cell=pc3d01 place_status = fixed)
                (inst name="I6"       cell=pc3d01 place_status = fixed)
                (inst name="I7"       cell=pc3d01 place_status = fixed))

     (topright  (inst name="CornerCell1" cell=pfrelr offset=0 orientation = R90 place_status = fixed))

     (top       (inst name="I8"       cell=pc3d01 place_status = fixed)
                (inst name="I9"       cell=pc3d01 place_status = fixed)
                (inst name="I10"      cell=pc3d01 place_status = fixed)
                (inst name="I11"      cell=pc3d01 place_status = fixed)
                (inst name="pvdi_T"   cell=pvdi   place_status = fixed)
                (inst name="pv0i_T"   cell=pv0i   place_status = fixed)
                (inst name="I12"      cell=pc3d01 place_status = fixed)
                (inst name="I13"      cell=pc3d01 place_status = fixed)
                (inst name="I14"      cell=pc3d01 place_status = fixed)
                (inst name="I15"      cell=pc3d01 place_status = fixed)
                (inst name="CLK_BUF"  cell=pc3c04 place_status = fixed)
                (inst name="CLK_PAD"  cell=pc3d01 place_status = fixed))

   (bottomright (inst name="CornerCell0" cell=pfrelr offset=0 orientation = R0 place_status = fixed))

     (right     (inst name="O8"       cell=pc3o01 place_status = fixed)
                (inst name="O9"       cell=pc3o01 place_status = fixed)
                (inst name="O10"      cell=pc3o01 place_status = fixed)
                (inst name="O11"      cell=pc3o01 place_status = fixed)
                (inst name="pv0f_R"   cell=pv0f   place_status = fixed)
                (inst name="O12"      cell=pc3o01 place_status = fixed)
                (inst name="O13"      cell=pc3o01 place_status = fixed)
                (inst name="O14"      cell=pc3o01 place_status = fixed)
                (inst name="LOAD_PAD" cell=pc3d01 place_status = fixed)
                (inst name="pv0c_R"   cell=pv0c   place_status = fixed)
                (inst name="pvdc_R"   cell=pvdc   place_status = fixed)
                (inst name="RST_PAD"  cell=pc3d01 place_status = fixed))

    (bottomleft (inst name="CornerCell3" cell=pfrelr offset=0 orientation = R270 place_status = fixed))

     (bottom    (inst name="pv0a_B"   cell=pv0a   place_status = fixed)
                (inst name="pvda_B"   cell=pvda   place_status = fixed)
                (inst name="O0"       cell=pc3o01 place_status = fixed)
                (inst name="O1"       cell=pc3o01 place_status = fixed)
                (inst name="O2"       cell=pc3o01 place_status = fixed)
                (inst name="O3"       cell=pc3o01 place_status = fixed)
                (inst name="pv0i_B"   cell=pv0i   place_status = fixed)
                (inst name="pvdi_B"   cell=pvdi   place_status = fixed)
                (inst name="O4"       cell=pc3o01 place_status = fixed)
                (inst name="O5"       cell=pc3o01 place_status = fixed)
                (inst name="O6"       cell=pc3o01 place_status = fixed)
                (inst name="O7"       cell=pc3o01 place_status = fixed))
)
)
