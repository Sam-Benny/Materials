# Educational Digital Processor (SCL 180nm ASIC & PYNQ-Z2 FPGA)

## 1. Overview
The **Educational Digital Processor** is a specialized, interactive processor design implemented for ASIC tapeout under the **SCL 180nm CMOS PDK** (4 Metal Layer flow) and FPGA validation on the **TUL PYNQ-Z2** (Xilinx Zynq-7000) board.

The design functions as an educational computing kit where users can physically manipulate 16 DIP switches, assert a `load` strobe, and witness instant decoding, execution, and output visualization on 8 data LEDs and dedicated status/carry flags.

---

## 2. Processor Architecture & Specification

### 2.1 Input Word Format (16-bit)
The input bus `in[15:0]` is divided into four 4-bit nibbles:
- **`in[15:12]` -> Opcode (`opcode[3:0]`)**: 4-bit instruction selection (16 operations).
- **`in[11:8]`  -> Register 1 (`rd1[3:0]`)**: 4-bit operand 1.
- **`in[7:4]`   -> Register 2 (`rd2[3:0]`)**: 4-bit operand 2.
- **`in[3:0]`   -> Memory Address (`mem_addr[3:0]`)**: 4-bit address for data memory access / shift amount.

### 2.2 Control Inputs
- **`clk`**: System clock (default: **20 MHz**, configurable via top-level parameter).
- **`rst`**: Synchronous active-high reset.
- **`load`**: Input strobe. Samples and latches the 16-bit input word into internal registers, triggers execution, and updates output registers.

### 2.3 Output & Flag Interfaces
- **`out[7:0]`**: 8-bit Result displayed on 8 LEDs (LSB right, MSB left).
- **`out[8]`**: Carry / Borrow flag output.
- **`out[9]`**: Zero Flag (`1` when `out[7:0] == 8'b0000_0000`).
- **`out[10]`**: Sign Flag (`out[7]`).
- **`out[11]`**: Result Parity Flag (Even parity of 8-bit output).
- **`out[12]`**: Overflow Flag (Arithmetic overflow / carry out).
- **`out[13]`**: Comparator Greater Than (`rd1 > rd2`).
- **`out[14]`**: Comparator Equal (`rd1 == rd2`).
- **`out[15]`**: Comparator Less Than (`rd1 < rd2`).

---

## 3. Instruction Set Architecture (16 Opcodes)

| Opcode | Mnemonic | Operation | Inputs | Output [7:0] | Carry (`out[8]`) | Description |
|:---:|:---:|:---:|:---:|:---:|:---:|:---|
| `0000` | **MEM_READ** | Memory Access | `mem_addr[3:0]` | `{4'b0, mem[addr]}` | `0` | Reads 4-bit value from 16-word data memory |
| `0001` | **ADD4** | 4-bit Adder | `rd1[3:0]`, `rd2[3:0]` | `{4'b0, sum[3:0]}` | `sum[4]` | 4-bit binary addition with carry out |
| `0010` | **SUB4** | 4-bit Subtractor | `rd1[3:0]`, `rd2[3:0]` | `{4'b0, diff[3:0]}` | `borrow` | 4-bit binary subtraction (`rd1 - rd2`) |
| `0011` | **AND** | Bitwise AND | `rd1[3:0]`, `rd2[3:0]` | `{4'b0, rd1 & rd2}` | `0` | 4-bit bitwise AND operation |
| `0100` | **OR** | Bitwise OR | `rd1[3:0]`, `rd2[3:0]` | `{4'b0, rd1 \| rd2}` | `0` | 4-bit bitwise OR operation |
| `0101` | **XOR** | Bitwise XOR | `rd1[3:0]`, `rd2[3:0]` | `{4'b0, rd1 ^ rd2}` | `0` | 4-bit bitwise XOR operation |
| `0110` | **ENCODER** | 8-to-3 Priority Enc | `{rd1, rd2}` (8-bit) | `{5'b0, code[2:0]}` | `valid` | Encodes highest active bit index (0 to 7) |
| `0111` | **DECODER** | 3-to-8 Decoder | `rd1[2:0]` (`in[10:8]`)| `1 << rd1[2:0]` | `0` | 3-to-8 One-hot decoded pattern |
| `1000` | **MUX4X1** | 4-to-1 Multiplexer | `rd1[3:0]`, `rd2[1:0]` | `{7'b0, mux_out}` | `0` | 4:1 MUX (`rd1`=data, `rd2[1:0]`=sel) |
| `1001` | **SHR** | Shift Right | `{rd1, rd2}` (8-bit) | `operand >> shamt` | `shifted_out` | 8-bit logical shift right (by `mem_addr`) |
| `1010` | **SHL** | Shift Left | `{rd1, rd2}` (8-bit) | `operand << shamt` | `shifted_out` | 8-bit logical shift left (by `mem_addr`) |
| `1011` | **ROT** | Rotate Right | `{rd1, rd2}` (8-bit) | `ROR(operand, shamt)`| `0` | 8-bit circular rotation right |
| `1100` | **TWOS_COMP**| 2's Complement | `{rd1, rd2}` (8-bit) | `~{rd1,rd2} + 1` | `0` | 8-bit two's complement arithmetic negation |
| `1101` | **BIN2GRAY** | Binary to Gray | `rd1[3:0]` | `{4'b0, gray[3:0]}` | `0` | 4-bit Binary to Gray code converter |
| `1110` | **PARITY_GEN**| Parity Generator | `rd1[3:0]` | `{3'b0, rd1, parity}`| `parity` | 4-bit even parity generation (`^rd1`) |
| `1111` | **COMP** | 4-bit Comparator | `rd1[3:0]`, `rd2[3:0]` | `{5'b0, LT, EQ, GT}` | `0` | Comparator: GT=`out[0]`, EQ=`out[1]`, LT=`out[2]` |

---

## 4. SCL 180nm ASIC Padframe & Pin Allocation (48 Pads)

The tapeout uses the standard 48-pad frame for SCL 180nm CMOS technology:
- **Digital Input Pad**: `pc3d01` (.PAD, .CIN)
- **Digital Output Pad**: `pc3o01` (.PAD, .I)
- **Clock Input Pad & Clock Buffer**: `pc3d01` (.PAD) + `pc3c04` (.CCLK, .CP)
- **Corner Cells**: `pfrelr` (4 corners: R0, R90, R180, R270)
- **Power & Ground Pads**: `pv0a`, `pvda`, `pv0c`, `pvdc`, `pv0i`, `pvdi`, `pv0f`

### 4.1 48-Pad Ring Layout Table

| Pad Edge | Slot | Instance Name | Pad Cell | Signal / Function | Description |
|---|:---:|:---:|:---:|:---:|:---|
| **Corner** | - | `CornerCell2` | `pfrelr` | Top-Left Corner | Orientation R180 |
| **LEFT** | 1 | `pv0a_L` | `pv0a` | `VSSO` | IO Ground (AC Section) |
| | 2 | `pvda_L` | `pvda` | `VDDO` | IO Power (AC Section) |
| | 3 | `I0` | `pc3d01` | `in[0]` | Memory Address bit 0 |
| | 4 | `I1` | `pc3d01` | `in[1]` | Memory Address bit 1 |
| | 5 | `I2` | `pc3d01` | `in[2]` | Memory Address bit 2 |
| | 6 | `I3` | `pc3d01` | `in[3]` | Memory Address bit 3 |
| | 7 | `pv0c_L` | `pv0c` | `VSS` | Core Ground |
| | 8 | `pvdc_L` | `pvdc` | `VDD` | Core Power |
| | 9 | `I4` | `pc3d01` | `in[4]` | Register 2 (RD2) bit 0 |
| | 10 | `I5` | `pc3d01` | `in[5]` | Register 2 (RD2) bit 1 |
| | 11 | `I6` | `pc3d01` | `in[6]` | Register 2 (RD2) bit 2 |
| | 12 | `I7` | `pc3d01` | `in[7]` | Register 2 (RD2) bit 3 |
| **Corner** | - | `CornerCell1` | `pfrelr` | Top-Right Corner | Orientation R90 |
| **TOP** | 1 | `I8` | `pc3d01` | `in[8]` | Register 1 (RD1) bit 0 |
| | 2 | `I9` | `pc3d01` | `in[9]` | Register 1 (RD1) bit 1 |
| | 3 | `I10` | `pc3d01` | `in[10]` | Register 1 (RD1) bit 2 |
| | 4 | `I11` | `pc3d01` | `in[11]` | Register 1 (RD1) bit 3 |
| | 5 | `pvdi_T` | `pvdi` | `VDD` | Core & Pre-driver Power |
| | 6 | `pv0i_T` | `pv0i` | `VSS` | Core & Pre-driver Ground |
| | 7 | `I12` | `pc3d01` | `in[12]` | Opcode bit 0 |
| | 8 | `I13` | `pc3d01` | `in[13]` | Opcode bit 1 |
| | 9 | `I14` | `pc3d01` | `in[14]` | Opcode bit 2 |
| | 10 | `I15` | `pc3d01` | `in[15]` | Opcode bit 3 |
| | 11 | `CLK_BUF` | `pc3c04` | Clock Buffer | Dedicated Clock Tree Pad Buffer |
| | 12 | `CLK_PAD` | `pc3d01` | `clk` | 20 MHz Clock Input Pad |
| **Corner** | - | `CornerCell0` | `pfrelr` | Bottom-Right Corner | Orientation R0 |
| **RIGHT** | 1 | `O8` | `pc3o01` | `out[8]` | Carry / Borrow LED |
| | 2 | `O9` | `pc3o01` | `out[9]` | Zero Status Flag |
| | 3 | `O10` | `pc3o01` | `out[10]` | Sign Status Flag |
| | 4 | `O11` | `pc3o01` | `out[11]` | Parity Status Flag |
| | 5 | `pv0f_R` | `pv0f` | `VSS` | VSS & VSSO Bus Short Pad |
| | 6 | `O12` | `pc3o01` | `out[12]` | Overflow Status Flag |
| | 7 | `O13` | `pc3o01` | `out[13]` | Comparator Greater Than (GT) Flag |
| | 8 | `O14` | `pc3o01` | `out[14]` | Comparator Equal (EQ) Flag |
| | 9 | `LOAD_PAD` | `pc3d01` | `load` | Load Strobe Input Pad |
| | 10 | `pv0c_R` | `pv0c` | `VSS` | Core Ground |
| | 11 | `pvdc_R` | `pvdc` | `VDD` | Core Power |
| | 12 | `RST_PAD` | `pc3d01` | `rst` | Synchronous Reset Input Pad |
| **Corner** | - | `CornerCell3` | `pfrelr` | Bottom-Left Corner | Orientation R270 |
| **BOTTOM**| 1 | `pv0a_B` | `pv0a` | `VSSO` | IO Ground (AC Section) |
| | 2 | `pvda_B` | `pvda` | `VDDO` | IO Power (AC Section) |
| | 3 | `O0` | `pc3o01` | `out[0]` | Result LED 0 (LSB) |
| | 4 | `O1` | `pc3o01` | `out[1]` | Result LED 1 |
| | 5 | `O2` | `pc3o01` | `out[2]` | Result LED 2 |
| | 6 | `O3` | `pc3o01` | `out[3]` | Result LED 3 |
| | 7 | `pv0i_B` | `pv0i` | `VSS` | Core & Pre-driver Ground |
| | 8 | `pvdi_B` | `pvdi` | `VDD` | Core & Pre-driver Power |
| | 9 | `O4` | `pc3o01` | `out[4]` | Result LED 4 |
| | 10 | `O5` | `pc3o01` | `out[5]` | Result LED 5 |
| | 11 | `O6` | `pc3o01` | `out[6]` | Result LED 6 |
| | 12 | `O7` | `pc3o01` | `out[7]` | Result LED 7 (MSB) |

---

## 5. Directory Structure

```
/home/user31/Sam/ASIC_Git/Processor/
├── rtl/
│   ├── alu_modules/
│   │   ├── adder4.v              # 4-bit adder with carry out
│   │   ├── subtractor4.v         # 4-bit subtractor with borrow
│   │   ├── logic_unit.v          # 4-bit AND, OR, XOR
│   │   ├── encoder8to3.v         # 8-to-3 priority encoder
│   │   ├── decoder3to8.v         # 3-to-8 one-hot decoder
│   │   ├── mux4to1.v             # 4-to-1 multiplexer
│   │   ├── shifter8.v            # 8-bit logical shift right, left & rotate
│   │   ├── twos_complement8.v    # 8-bit two's complement
│   │   ├── bin2gray.v            # 4-bit binary to gray code converter
│   │   ├── parity_gen.v          # 4-bit even parity generator
│   │   ├── comparator4.v         # 4-bit magnitude comparator (GT, EQ, LT)
│   │   └── data_memory.v         # 16x4-bit synchronous data memory
│   ├── edu_alu.v                 # Unified ALU execution multiplexer
│   ├── edu_processor_core.v      # Register latch, decoder, ALU & status controller
│   ├── top_edu_processor.v       # Parameterizable 20 MHz core top-level module
│   ├── chip_top.v                # SCL 180nm 48-pad ASIC top-level with IO cells
│   └── fpga_top.v                # PYNQ-Z2 FPGA top wrapper with clock divider & debouncer
├── tb/
│   ├── tb_adder4.v               # Adder unit testbench
│   ├── tb_subtractor4.v          # Subtractor unit testbench
│   ├── tb_logic_unit.v           # Logic unit testbench
│   ├── tb_encoder8to3.v          # Priority encoder testbench
│   ├── tb_decoder3to8.v          # Decoder testbench
│   ├── tb_mux4to1.v              # Multiplexer testbench
│   ├── tb_shifter8.v             # Shifter/Rotator testbench
│   ├── tb_twos_complement8.v     # Two's complement testbench
│   ├── tb_bin2gray.v             # Binary to Gray converter testbench
│   ├── tb_parity_gen.v           # Parity generator testbench
│   ├── tb_comparator4.v          # Comparator testbench
│   ├── tb_data_memory.v          # Memory testbench
│   ├── tb_edu_processor_core.v   # Complete 16-instruction core testbench
│   ├── tb_chip_top.v             # SCL 180nm Padframe chip testbench
│   └── tb_fpga_top.v             # PYNQ-Z2 FPGA simulation testbench
├── synthesis/
│   ├── synthesis.tcl             # Cadence Genus synthesis script for SCL 180nm
│   └── constraints.sdc           # SDC timing constraints (20 MHz / 50ns clock)
├── layout/
│   ├── top_netlist.io            # Cadence Innovus 48-pad IO assignment file
│   ├── top.globals               # Innovus configuration & library pointers
│   └── top.view                  # MMMC multi-corner timing definition
├── fpga/
│   └── pynq_z2_constraints.xdc   # Xilinx Vivado XDC constraints for PYNQ-Z2
└── README.md                     # Comprehensive project documentation
```

---

## 6. SDC Timing & Clock Constraints (20 MHz)

The constraints file `synthesis/constraints.sdc` is configured for **20 MHz** (`clk_period = 50.0 ns`):
- **Clock Period**: `50.0 ns`
- **Clock Transition**: Rise/Fall min = `6.25 ns` (`0.125 * period`), max = `10.0 ns` (`0.20 * period`)
- **Clock Uncertainty**: Setup/Hold = `1.25 ns` (`0.025 * period`)
- **Clock Latency**: Max = `2.5 ns`, Min = `0.5 ns`
- **Input Delay**: Max = `15.0 ns`, Min = `5.0 ns`
- **Output Delay**: Max = `10.0 ns`, Min = `4.0 ns`
- **Output Load**: `5.0 pF`
- **Path Grouping**: `I2R`, `R2O`, `R2R`, `I2O`

To change the clock frequency in the future, simply update the `set clk_period <val>` in `synthesis/constraints.sdc` and the `CLK_FREQ_HZ` parameter in `top_edu_processor.v`.

---

## 7. ASIC Flow Guide (Cadence Genus & Innovus)

### 7.1 Synthesis (Cadence Genus)
```bash
cd /home/user31/Sam/ASIC_Git/Processor/synthesis
genus -f synthesis.tcl
```
Outputs produced:
- `core_netlist.v`: Gate-level Verilog netlist
- `sdc.sdc`: Post-synthesis timing constraints
- `sdf.sdf`: Standard delay format file
- `reports/timing.rpt`, `reports/area.rpt`, `reports/power.rpt`, `reports/gates.rpt`

### 7.2 Floorplanning & PnR (Cadence Innovus)
```bash
cd /home/user31/Sam/ASIC_Git/Processor/layout
innovus -init top.globals
```
The flow automatically imports the pad IO assignments from `top_netlist.io`, applies MMMC views from `top.view`, places the standard cells and IO pads, creates the power ring (`VDD`, `VSS`, `VDDO`, `VSSO`), routes clock tree synthesis (CTS) using `pc3c04`, and performs detailed routing for GDSII tapeout.

---

## 8. FPGA Verification Guide (PYNQ-Z2)

1. Open **Xilinx Vivado**.
2. Create a project targeting `xc7z020clg400-1`.
3. Add all Verilog files in `rtl/` and `rtl/alu_modules/`.
4. Set `fpga_top.v` as the Top Module.
5. Add `fpga/pynq_z2_constraints.xdc` as the constraint file.
6. Run Synthesis -> Implementation -> Generate Bitstream.
7. Program the PYNQ-Z2 board via Vivado Hardware Manager.
8. **Interactive Operation**:
   - Set 16 DIP switches: `[15:12]`=Opcode, `[11:8]`=RD1, `[7:4]`=RD2, `[3:0]`=MemAddr.
   - Press `btn[1]` to pulse `load` (or enable `sw[0]` for continuous evaluation).
   - Observe the 8-bit result on LEDs, carry on `led_carry`, and status on RGB LEDs.
   - Press `btn[0]` to reset.
