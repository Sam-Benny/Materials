// Testbench for 8-bit Two's Complement (twos_complement8)
`timescale 1ns / 1ps

module tb_twos_complement8;
    reg  [7:0] in;
    wire [7:0] out;

    integer errors = 0;
    integer i;
    reg [7:0] expected;

    twos_complement8 uut (
        .in(in),
        .out(out)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_twos_complement8 Testbench");
        $display("========================================");

        for (i = 0; i < 256; i = i + 1) begin
            in = i[7:0];
            #5;
            expected = -in;
            if (out !== expected) begin
                $display("ERROR: in=%d -> expected %d, got %d", in, expected, out);
                errors = errors + 1;
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_twos_complement8 passed all 256 test vectors!");
        else
            $display("FAILURE: tb_twos_complement8 encountered %0d errors.", errors);
        $finish;
    end
endmodule
