// Testbench for Logic Unit (logic_unit)
`timescale 1ns / 1ps

module tb_logic_unit;
    reg  [3:0] a;
    reg  [3:0] b;
    wire [3:0] and_out;
    wire [3:0] or_out;
    wire [3:0] xor_out;

    integer errors = 0;
    integer i, j;

    logic_unit uut (
        .a(a),
        .b(b),
        .and_out(and_out),
        .or_out(or_out),
        .xor_out(xor_out)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_logic_unit Testbench");
        $display("========================================");
        for (i = 0; i < 16; i = i + 1) begin
            for (j = 0; j < 16; j = j + 1) begin
                a = i[3:0];
                b = j[3:0];
                #5;
                if (and_out !== (a & b) || or_out !== (a | b) || xor_out !== (a ^ b)) begin
                    $display("ERROR: a=%b b=%b -> AND=%b OR=%b XOR=%b", a, b, and_out, or_out, xor_out);
                    errors = errors + 1;
                end
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_logic_unit passed all 256 test vectors!");
        else
            $display("FAILURE: tb_logic_unit encountered %0d errors.", errors);
        $finish;
    end
endmodule
