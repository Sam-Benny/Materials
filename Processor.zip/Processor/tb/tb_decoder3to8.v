// Testbench for 3-to-8 Decoder (decoder3to8)
`timescale 1ns / 1ps

module tb_decoder3to8;
    reg  [2:0] in;
    reg        en;
    wire [7:0] out;

    integer errors = 0;
    integer i;

    decoder3to8 uut (
        .in(in),
        .en(en),
        .out(out)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_decoder3to8 Testbench");
        $display("========================================");

        // Disabled test
        en = 0;
        for (i = 0; i < 8; i = i + 1) begin
            in = i[2:0];
            #5;
            if (out !== 8'h00) begin
                $display("ERROR: Disabled decoder produced non-zero output: %b", out);
                errors = errors + 1;
            end
        end

        // Enabled test
        en = 1;
        for (i = 0; i < 8; i = i + 1) begin
            in = i[2:0];
            #5;
            if (out !== (8'b00000001 << in)) begin
                $display("ERROR: in=%d -> expected %b, got %b", in, (8'b00000001 << in), out);
                errors = errors + 1;
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_decoder3to8 passed all tests!");
        else
            $display("FAILURE: tb_decoder3to8 encountered %0d errors.", errors);
        $finish;
    end
endmodule
