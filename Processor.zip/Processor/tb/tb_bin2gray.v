// Testbench for 4-bit Binary to Gray Code Converter (bin2gray)
`timescale 1ns / 1ps

module tb_bin2gray;
    reg  [3:0] bin;
    wire [3:0] gray;

    integer errors = 0;
    integer i;
    reg [3:0] expected;

    bin2gray uut (
        .bin(bin),
        .gray(gray)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_bin2gray Testbench");
        $display("========================================");

        for (i = 0; i < 16; i = i + 1) begin
            bin = i[3:0];
            #5;
            expected = bin ^ (bin >> 1);
            if (gray !== expected) begin
                $display("ERROR: bin=%b -> expected gray=%b, got %b", bin, expected, gray);
                errors = errors + 1;
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_bin2gray passed all 16 test vectors!");
        else
            $display("FAILURE: tb_bin2gray encountered %0d errors.", errors);
        $finish;
    end
endmodule
