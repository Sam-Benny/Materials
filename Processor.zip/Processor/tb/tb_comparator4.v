// Testbench for 4-bit Magnitude Comparator (comparator4)
`timescale 1ns / 1ps

module tb_comparator4;
    reg  [3:0] a;
    reg  [3:0] b;
    wire       gt;
    wire       eq;
    wire       lt;
    wire [2:0] comp_bus;

    integer errors = 0;
    integer i, j;

    comparator4 uut (
        .a(a),
        .b(b),
        .gt(gt),
        .eq(eq),
        .lt(lt),
        .comp_bus(comp_bus)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_comparator4 Testbench");
        $display("========================================");

        for (i = 0; i < 16; i = i + 1) begin
            for (j = 0; j < 16; j = j + 1) begin
                a = i[3:0];
                b = j[3:0];
                #5;
                if (gt !== (a > b) || eq !== (a == b) || lt !== (a < b)) begin
                    $display("ERROR: a=%d b=%d -> GT=%b EQ=%b LT=%b (expected %b %b %b)",
                             a, b, gt, eq, lt, (a > b), (a == b), (a < b));
                    errors = errors + 1;
                end
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_comparator4 passed all 256 test vectors!");
        else
            $display("FAILURE: tb_comparator4 encountered %0d errors.", errors);
        $finish;
    end
endmodule
