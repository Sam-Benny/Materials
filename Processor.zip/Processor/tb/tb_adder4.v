// Testbench for 4-bit Binary Adder (adder4)
`timescale 1ns / 1ps

module tb_adder4;
    reg  [3:0] a;
    reg  [3:0] b;
    reg        cin;
    wire [3:0] sum;
    wire       cout;

    integer errors = 0;
    integer i, j;

    adder4 uut (
        .a(a),
        .b(b),
        .cin(cin),
        .sum(sum),
        .cout(cout)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_adder4 Testbench");
        $display("========================================");
        cin = 0;
        for (i = 0; i < 16; i = i + 1) begin
            for (j = 0; j < 16; j = j + 1) begin
                a = i[3:0];
                b = j[3:0];
                #5;
                if ({cout, sum} !== (a + b + cin)) begin
                    $display("ERROR: a=%d b=%d cin=%b -> expected %d, got {cout,sum}=%b", a, b, cin, a+b+cin, {cout, sum});
                    errors = errors + 1;
                end
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_adder4 passed all 256 test vectors!");
        else
            $display("FAILURE: tb_adder4 encountered %0d errors.", errors);
        $finish;
    end
endmodule
