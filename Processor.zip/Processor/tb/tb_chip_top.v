// ASIC Chip Top Testbench for SCL 180nm Padframe
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Simulates chip_top with 20 MHz clock through IO pad models.

`timescale 1ns / 1ps

// Behavioral Mock Models for SCL 180nm IO Pad Cells for Simulation
`ifndef SCL180_PAD_MODELS_DEFINED
`define SCL180_PAD_MODELS_DEFINED

module pc3d01 (input wire PAD, output wire CIN);
    assign #0.5 CIN = PAD;
endmodule

module pc3o01 (input wire I, output wire PAD);
    assign #0.5 PAD = I;
endmodule

module pc3c04 (input wire CCLK, output wire CP);
    assign #0.2 CP = CCLK;
endmodule

module pvdc (input wire VDDC); endmodule
module pv0c (input wire VSSC); endmodule
module pvda (input wire VDDO); endmodule
module pv0a (input wire VSSO); endmodule
module pvdi (input wire VDD);  endmodule
module pv0i (input wire VSS);  endmodule
module pv0f (input wire VSS);  endmodule

`endif

module tb_chip_top;

    reg  [15:0] in;
    wire [14:0] out;
    reg         clk;
    reg         rst;
    reg         load;

    integer errors = 0;

    // Instantiate ASIC Chip Top with 48 IO Pads
    chip_top uut_chip (
        .in(in),
        .out(out),
        .clk(clk),
        .rst(rst),
        .load(load)
    );

    // 20 MHz Clock Generator
    always #25 clk = ~clk;

    initial begin
        clk  = 0;
        rst  = 1;
        load = 0;
        in   = 16'h0000;

        $display("================================================================");
        $display(" STARTING ASIC CHIP TOP (48-PAD FRAME) VERIFICATION             ");
        $display(" Clock: 20 MHz (50ns Period) | SCL 180nm Padring                ");
        $display("================================================================");

        #120;
        @(posedge clk);
        rst = 0;
        #50;

        // Test 1: Addition (Opcode 0001) -> 6 + 7 = 13 (0xD)
        @(posedge clk);
        in = {4'b0001, 4'd6, 4'd7, 4'd0};
        load = 1'b1;
        @(posedge clk);
        load = 1'b0;
        @(posedge clk);
        #2;
        if (out[7:0] !== 8'h0D) begin
            $display("ERROR [Chip Top Add]: Expected 0x0D, got 0x%h", out[7:0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Chip Top Add]: 6 + 7 = %0d (Carry=%b)", out[3:0], out[8]);
        end

        // Test 2: Logic XOR (Opcode 0101) -> 0x5 ^ 0x3 = 0x6
        @(posedge clk);
        in = {4'b0101, 4'h5, 4'h3, 4'd0};
        load = 1'b1;
        @(posedge clk);
        load = 1'b0;
        @(posedge clk);
        #2;
        if (out[7:0] !== 8'h06) begin
            $display("ERROR [Chip Top XOR]: Expected 0x06, got 0x%h", out[7:0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Chip Top XOR]: 0x5 ^ 0x3 = 0x%h", out[7:0]);
        end

        // Test 3: Decoder (Opcode 0111) -> 3-bit = 2 -> 8-bit = 8'b00000100 (0x04)
        @(posedge clk);
        in = {4'b0111, 4'b0010, 4'h0, 4'h0};
        load = 1'b1;
        @(posedge clk);
        load = 1'b0;
        @(posedge clk);
        #2;
        if (out[7:0] !== 8'h04) begin
            $display("ERROR [Chip Top Decoder]: Expected 0x04, got 0x%h", out[7:0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Chip Top Decoder]: Decode(2) -> %b", out[7:0]);
        end

        $display("\n================================================================");
        if (errors == 0)
            $display(" ASIC CHIP TOP PADFRAME VERIFICATION PASSED SUCCESSFULLY!       ");
        else
            $display(" ASIC CHIP TOP FAILED WITH %0d ERRORS.                          ", errors);
        $display("================================================================\n");

        $finish;
    end

endmodule
