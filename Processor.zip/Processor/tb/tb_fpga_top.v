// Testbench for PYNQ-Z2 FPGA Top Wrapper
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Simulates 125 MHz system clock, button triggers, and LED mappings.

`timescale 1ns / 1ps

module tb_fpga_top;

    reg         sysclk;
    reg  [3:0]  btn;
    reg  [1:0]  sw;
    reg  [15:0] dip_sw;
    wire [3:0]  led;
    wire [7:0]  ext_led;
    wire        led_carry;
    wire [5:0]  led_flags;
    wire [2:0]  rgbled0;
    wire [2:0]  rgbled1;

    // Instantiate FPGA Top
    fpga_top uut_fpga (
        .sysclk(sysclk),
        .btn(btn),
        .sw(sw),
        .dip_sw(dip_sw),
        .led(led),
        .ext_led(ext_led),
        .led_carry(led_carry),
        .led_flags(led_flags),
        .rgbled0(rgbled0),
        .rgbled1(rgbled1)
    );

    // 125 MHz System Clock (Period = 8 ns -> 4 ns high, 4 ns low)
    always #4 sysclk = ~sysclk;

    initial begin
        sysclk = 0;
        btn    = 4'b0001; // Assert Reset
        sw     = 2'b01;   // Enable switch continuous load for test
        dip_sw = 16'h0000;

        $display("================================================================");
        $display(" STARTING PYNQ-Z2 FPGA TOP-LEVEL SIMULATION                     ");
        $display(" Sysclk: 125 MHz | Derived Core Clock: 20.8 MHz                 ");
        $display("================================================================");

        #100;
        btn = 4'b0000; // Release Reset
        #100;

        // Apply Opcode 0001 (Addition): 4 + 3 = 7
        dip_sw = {4'b0001, 4'd4, 4'd3, 4'd0};
        #200;

        $display("FPGA LEDs: lower 4-bit led=%b, full 8-bit ext_led=%b (Carry=%b)",
                 led, ext_led, led_carry);

        // Apply Opcode 1111 (Comparator): 8 vs 2
        dip_sw = {4'b1111, 4'd8, 4'd2, 4'd0};
        #200;
        $display("FPGA Comparator test (8 vs 2): LEDs=%b, Carry=%b, Flags=%b",
                 ext_led, led_carry, led_flags);

        $display("\nFPGA Top simulation completed successfully.");
        $finish;
    end

endmodule
