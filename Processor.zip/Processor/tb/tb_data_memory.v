// Testbench for 16x4 Data Memory (data_memory)
`timescale 1ns / 1ps

module tb_data_memory;
    reg        clk;
    reg        rst;
    reg        we;
    reg  [3:0] addr;
    reg  [3:0] din;
    wire [3:0] dout;

    integer errors = 0;
    integer i;

    data_memory uut (
        .clk(clk),
        .rst(rst),
        .we(we),
        .addr(addr),
        .din(din),
        .dout(dout)
    );

    always #25 clk = ~clk; // 20 MHz clock (50ns period)

    initial begin
        clk = 0;
        rst = 1;
        we  = 0;
        addr = 0;
        din  = 0;

        $display("========================================");
        $display("Starting tb_data_memory Testbench");
        $display("========================================");

        #100;
        rst = 0;
        #50;

        // Verify initial reset contents
        for (i = 0; i < 16; i = i + 1) begin
            addr = i[3:0];
            #50;
            $display("Read Addr %0d: Data = 0x%h", addr, dout);
        end

        // Test Write and Read
        we = 1;
        addr = 4'h3;
        din = 4'hC;
        #50;
        we = 0;
        #50;
        if (dout !== 4'hC) begin
            $display("ERROR: Written 0xC to addr 3, but read 0x%h", dout);
            errors = errors + 1;
        end

        if (errors == 0)
            $display("SUCCESS: tb_data_memory passed all tests!");
        else
            $display("FAILURE: tb_data_memory encountered %0d errors.", errors);
        $finish;
    end
endmodule
