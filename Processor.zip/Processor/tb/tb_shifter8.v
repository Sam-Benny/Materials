// Testbench for 8-bit Shifter / Rotator (shifter8)
`timescale 1ns / 1ps

module tb_shifter8;
    reg  [7:0] in;
    reg  [2:0] shamt;
    reg  [1:0] mode;
    wire [7:0] out;
    wire       cout;

    integer errors = 0;

    shifter8 uut (
        .in(in),
        .shamt(shamt),
        .mode(mode),
        .out(out),
        .cout(cout)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_shifter8 Testbench");
        $display("========================================");

        // Test SHR (mode=00)
        in = 8'b10110011; shamt = 3'd1; mode = 2'b00; #5;
        if (out !== 8'b01011001 || cout !== 1'b1) begin
            $display("ERROR in SHR: expected 8'b01011001 cout=1, got %b cout=%b", out, cout);
            errors = errors + 1;
        end

        // Test SHL (mode=01)
        in = 8'b10110011; shamt = 3'd1; mode = 2'b01; #5;
        if (out !== 8'b01100110 || cout !== 1'b1) begin
            $display("ERROR in SHL: expected 8'b01100110 cout=1, got %b cout=%b", out, cout);
            errors = errors + 1;
        end

        // Test ROR (mode=10)
        in = 8'b10110011; shamt = 3'd1; mode = 2'b10; #5;
        if (out !== 8'b11011001) begin
            $display("ERROR in ROR: expected 8'b11011001, got %b", out);
            errors = errors + 1;
        end

        // Test ROL (mode=11)
        in = 8'b10110011; shamt = 3'd1; mode = 2'b11; #5;
        if (out !== 8'b01100111) begin
            $display("ERROR in ROL: expected 8'b01100111, got %b", out);
            errors = errors + 1;
        end

        if (errors == 0)
            $display("SUCCESS: tb_shifter8 passed all tests!");
        else
            $display("FAILURE: tb_shifter8 encountered %0d errors.", errors);
        $finish;
    end
endmodule
