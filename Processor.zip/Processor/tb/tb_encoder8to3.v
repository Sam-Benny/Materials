// Testbench for 8-to-3 Priority Encoder (encoder8to3)
`timescale 1ns / 1ps

module tb_encoder8to3;
    reg  [7:0] in;
    wire [2:0] code;
    wire       valid;

    integer errors = 0;
    integer i;
    reg [2:0] expected_code;
    reg       expected_valid;

    encoder8to3 uut (
        .in(in),
        .code(code),
        .valid(valid)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_encoder8to3 Testbench");
        $display("========================================");

        // Test all 256 combinations
        for (i = 0; i < 256; i = i + 1) begin
            in = i[7:0];
            #5;
            expected_valid = (in != 8'h00);
            if (in[7])      expected_code = 3'd7;
            else if (in[6]) expected_code = 3'd6;
            else if (in[5]) expected_code = 3'd5;
            else if (in[4]) expected_code = 3'd4;
            else if (in[3]) expected_code = 3'd3;
            else if (in[2]) expected_code = 3'd2;
            else if (in[1]) expected_code = 3'd1;
            else if (in[0]) expected_code = 3'd0;
            else            expected_code = 3'd0;

            if (code !== expected_code || valid !== expected_valid) begin
                $display("ERROR: in=%b -> expected code=%d valid=%b, got code=%d valid=%b",
                         in, expected_code, expected_valid, code, valid);
                errors = errors + 1;
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_encoder8to3 passed all 256 test vectors!");
        else
            $display("FAILURE: tb_encoder8to3 encountered %0d errors.", errors);
        $finish;
    end
endmodule
