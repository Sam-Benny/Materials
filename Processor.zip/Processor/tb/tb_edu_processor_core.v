// Comprehensive Testbench for Educational Digital Processor Core
// Part of Educational Digital Processor (SCL 180nm ASIC / FPGA)
// Tests all 16 opcodes, control load strobe, reset, and output flags.

`timescale 1ns / 1ps

module tb_edu_processor_core;

    // Clock and Control Signals
    reg         clk;
    reg         rst;
    reg         load;
    reg  [15:0] in;
    wire [15:0] out;

    // Split output wires for convenient monitoring
    wire [7:0] result;
    wire       carry;
    wire       zero;
    wire       sign;
    wire       parity;
    wire       overflow;
    wire       comp_gt;
    wire       comp_eq;
    wire       comp_lt;

    assign result   = out[7:0];
    assign carry    = out[8];
    assign zero     = out[9];
    assign sign     = out[10];
    assign parity   = out[11];
    assign overflow = out[12];
    assign comp_gt  = out[13];
    assign comp_eq  = out[14];
    assign comp_lt  = out[15];

    integer errors = 0;

    // Instantiate Top-Level Processor Core
    top_edu_processor #(
        .CLK_FREQ_HZ(20_000_000),
        .CLK_PERIOD_NS(50)
    ) uut (
        .in(in),
        .load(load),
        .clk(clk),
        .rst(rst),
        .out(out)
    );

    // 20 MHz Clock Generator (Period = 50 ns -> 25 ns high, 25 ns low)
    always #25 clk = ~clk;

    // Helper task to execute an instruction
    task execute_instruction;
        input [3:0] op;
        input [3:0] r1;
        input [3:0] r2;
        input [3:0] mem;
        begin
            @(posedge clk);
            in   = {op, r1, r2, mem};
            load = 1'b1;
            @(posedge clk);
            load = 1'b0;
            @(posedge clk);
            #1; // Small delta for stable check
        end
    endtask

    initial begin
        // Initialize Signals
        clk  = 0;
        rst  = 1;
        load = 0;
        in   = 16'h0000;

        $display("================================================================");
        $display(" STARTING COMPREHENSIVE EDUCATIONAL PROCESSOR VERIFICATION     ");
        $display(" Clock: 20 MHz (Period: 50ns) | Target: SCL 180nm / PYNQ-Z2   ");
        $display("================================================================");

        // Reset Sequence
        #120;
        @(posedge clk);
        rst = 0;
        #50;

        //--------------------------------------------------------------
        // 1. Opcode 0000: Memory Read
        // Address 0x2 default data is 0xA (4'b1010)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 0 (0000): MEM_READ ---");
        execute_instruction(4'b0000, 4'h0, 4'h0, 4'h2);
        if (result !== 8'h0A) begin
            $display("ERROR [Op 0]: Expected result=0x0A, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 0]: Memory Read at addr 0x2 -> Data = 0x%h", result);
        end

        //--------------------------------------------------------------
        // 2. Opcode 0001: 4-bit Adder
        // rd1 = 4'h9 (9), rd2 = 4'h8 (8) -> Sum = 17 = 0x11 -> result=0x01, carry=1
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 1 (0001): ADD4 ---");
        execute_instruction(4'b0001, 4'h9, 4'h8, 4'h0);
        if (result !== 8'h01 || carry !== 1'b1) begin
            $display("ERROR [Op 1]: Expected result=0x01 carry=1, got result=0x%h carry=%b", result, carry);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 1]: 9 + 8 -> Result = %0d, Carry = %b", result[3:0], carry);
        end

        //--------------------------------------------------------------
        // 3. Opcode 0010: 4-bit Subtractor
        // rd1 = 4'h5 (5), rd2 = 4'h9 (9) -> Diff = 12 (0xC), Borrow = 1
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 2 (0010): SUB4 ---");
        execute_instruction(4'b0010, 4'h5, 4'h9, 4'h0);
        if (result[3:0] !== 4'hC || carry !== 1'b1) begin
            $display("ERROR [Op 2]: Expected diff=0xC borrow=1, got result=0x%h borrow=%b", result, carry);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 2]: 5 - 9 -> Diff = 0x%h, Borrow = %b", result[3:0], carry);
        end

        //--------------------------------------------------------------
        // 4. Opcode 0011: Bitwise AND
        // rd1 = 4'b1100, rd2 = 4'b1010 -> AND = 4'b1000 (0x8)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 3 (0011): AND ---");
        execute_instruction(4'b0011, 4'b1100, 4'b1010, 4'h0);
        if (result !== 8'h08) begin
            $display("ERROR [Op 3]: Expected 0x08, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 3]: 1100 & 1010 -> Result = %b", result[3:0]);
        end

        //--------------------------------------------------------------
        // 5. Opcode 0100: Bitwise OR
        // rd1 = 4'b1100, rd2 = 4'b1010 -> OR = 4'b1110 (0xE)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 4 (0100): OR ---");
        execute_instruction(4'b0100, 4'b1100, 4'b1010, 4'h0);
        if (result !== 8'h0E) begin
            $display("ERROR [Op 4]: Expected 0x0E, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 4]: 1100 | 1010 -> Result = %b", result[3:0]);
        end

        //--------------------------------------------------------------
        // 6. Opcode 0101: Bitwise XOR
        // rd1 = 4'b1100, rd2 = 4'b1010 -> XOR = 4'b0110 (0x6)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 5 (0101): XOR ---");
        execute_instruction(4'b0101, 4'b1100, 4'b1010, 4'h0);
        if (result !== 8'h06) begin
            $display("ERROR [Op 5]: Expected 0x06, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 5]: 1100 ^ 1010 -> Result = %b", result[3:0]);
        end

        //--------------------------------------------------------------
        // 7. Opcode 0110: 8-to-3 Priority Encoder
        // {rd1, rd2} = 8'b0010_0000 (bit 5 high) -> Encoded = 3'd5
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 6 (0110): ENCODER ---");
        execute_instruction(4'b0110, 4'b0010, 4'b0000, 4'h0);
        if (result[2:0] !== 3'd5) begin
            $display("ERROR [Op 6]: Expected code=5, got %d", result[2:0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 6]: 8-bit input 00100000 -> Encoded Code = %d", result[2:0]);
        end

        //--------------------------------------------------------------
        // 8. Opcode 0111: 3-to-8 Decoder
        // rd1[2:0] = 3'd3 -> Decoder out = 8'b0000_1000 (0x08)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 7 (0111): DECODER ---");
        execute_instruction(4'b0111, 4'b0011, 4'b0000, 4'h0);
        if (result !== 8'h08) begin
            $display("ERROR [Op 7]: Expected 0x08, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 7]: 3-bit input 3 -> Decoded 8-bit = %b", result);
        end

        //--------------------------------------------------------------
        // 9. Opcode 1000: 4x1 Multiplexer
        // rd1 = 4'b1010 (in3=1, in2=0, in1=1, in0=0), rd2[1:0] = 2'b11 (sel=3) -> out=1
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 8 (1000): MUX4X1 ---");
        execute_instruction(4'b1000, 4'b1010, 4'b0011, 4'h0);
        if (result[0] !== 1'b1) begin
            $display("ERROR [Op 8]: Expected mux out=1, got %b", result[0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 8]: MUX data 1010 sel 3 -> Out = %b", result[0]);
        end

        //--------------------------------------------------------------
        // 10. Opcode 1001: Shift Right
        // {rd1, rd2} = 8'b1010_1100, shamt=1 -> 8'b0101_0110 (0x56), carry=0
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 9 (1001): SHR ---");
        execute_instruction(4'b1001, 4'b1010, 4'b1100, 4'h1);
        if (result !== 8'h56) begin
            $display("ERROR [Op 9]: Expected 0x56, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 9]: 10101100 >> 1 -> Result = %b", result);
        end

        //--------------------------------------------------------------
        // 11. Opcode 1010: Shift Left
        // {rd1, rd2} = 8'b0010_1101, shamt=1 -> 8'b0101_1010 (0x5A)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 10 (1010): SHL ---");
        execute_instruction(4'b1010, 4'b0010, 4'b1101, 4'h1);
        if (result !== 8'h5A) begin
            $display("ERROR [Op 10]: Expected 0x5A, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 10]: 00101101 << 1 -> Result = %b", result);
        end

        //--------------------------------------------------------------
        // 12. Opcode 1011: Rotate
        // {rd1, rd2} = 8'b1000_0001, shamt=1 -> ROR = 8'b1100_0000 (0xC0)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 11 (1011): ROT ---");
        execute_instruction(4'b1011, 4'b1000, 4'b0001, 4'h1);
        if (result !== 8'hC0) begin
            $display("ERROR [Op 11]: Expected 0xC0, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 11]: 10000001 ROR 1 -> Result = %b", result);
        end

        //--------------------------------------------------------------
        // 13. Opcode 1100: 2's Complement
        // {rd1, rd2} = 8'h01 -> 2's complement = 8'hFF
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 12 (1100): TWOS_COMP ---");
        execute_instruction(4'b1100, 4'h0, 4'h1, 4'h0);
        if (result !== 8'hFF) begin
            $display("ERROR [Op 12]: Expected 0xFF, got 0x%h", result);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 12]: ~0x01 + 1 -> Result = 0x%h", result);
        end

        //--------------------------------------------------------------
        // 14. Opcode 1101: Binary to Gray
        // rd1 = 4'b1010 -> Gray = 1010 ^ 0101 = 4'b1111 (0xF)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 13 (1101): BIN2GRAY ---");
        execute_instruction(4'b1101, 4'b1010, 4'h0, 4'h0);
        if (result[3:0] !== 4'hF) begin
            $display("ERROR [Op 13]: Expected 0xF, got 0x%h", result[3:0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 13]: Bin 1010 -> Gray = %b", result[3:0]);
        end

        //--------------------------------------------------------------
        // 15. Opcode 1110: Even Parity Generator
        // rd1 = 4'b0111 (3 ones -> odd -> parity bit = 1)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 14 (1110): PARITY_GEN ---");
        execute_instruction(4'b1110, 4'b0111, 4'h0, 4'h0);
        if (carry !== 1'b1 || result[0] !== 1'b1) begin
            $display("ERROR [Op 14]: Expected parity=1, got carry=%b result[0]=%b", carry, result[0]);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 14]: 4-bit 0111 -> Even Parity Bit = %b", carry);
        end

        //--------------------------------------------------------------
        // 16. Opcode 1111: 4-bit Comparator
        // Test GT: rd1=7, rd2=4 -> out[0]=1 (GT), out[1]=0 (EQ), out[2]=0 (LT)
        //--------------------------------------------------------------
        $display("\n--- Testing Opcode 15 (1111): COMP ---");
        execute_instruction(4'b1111, 4'd7, 4'd4, 4'h0);
        if (comp_gt !== 1'b1 || comp_eq !== 1'b0 || comp_lt !== 1'b0) begin
            $display("ERROR [Op 15 GT]: Expected GT=1 EQ=0 LT=0, got %b %b %b", comp_gt, comp_eq, comp_lt);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 15 GT]: 7 vs 4 -> GT=%b, EQ=%b, LT=%b", comp_gt, comp_eq, comp_lt);
        end

        // Test EQ: rd1=5, rd2=5 -> out[1]=1 (EQ)
        execute_instruction(4'b1111, 4'd5, 4'd5, 4'h0);
        if (comp_eq !== 1'b1) begin
            $display("ERROR [Op 15 EQ]: Expected EQ=1, got GT=%b EQ=%b LT=%b", comp_gt, comp_eq, comp_lt);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 15 EQ]: 5 vs 5 -> GT=%b, EQ=%b, LT=%b", comp_gt, comp_eq, comp_lt);
        end

        // Test LT: rd1=2, rd2=8 -> out[2]=1 (LT)
        execute_instruction(4'b1111, 4'd2, 4'd8, 4'h0);
        if (comp_lt !== 1'b1) begin
            $display("ERROR [Op 15 LT]: Expected LT=1, got GT=%b EQ=%b LT=%b", comp_gt, comp_eq, comp_lt);
            errors = errors + 1;
        end else begin
            $display("PASS  [Op 15 LT]: 2 vs 8 -> GT=%b, EQ=%b, LT=%b", comp_gt, comp_eq, comp_lt);
        end

        // Summary
        $display("\n================================================================");
        if (errors == 0) begin
            $display(" ALL TESTS PASSED SUCCESSFULLY! (0 Errors)                      ");
            $display(" Educational Digital Processor Core is Verified and Clean!     ");
        end else begin
            $display(" VERIFICATION FAILED: %0d error(s) detected.                   ", errors);
        end
        $display("================================================================\n");

        $finish;
    end

endmodule
