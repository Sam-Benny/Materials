// Testbench for Even Parity Generator (parity_gen)
`timescale 1ns / 1ps

module tb_parity_gen;
    reg  [3:0] in;
    wire       parity;
    wire [4:0] out_frame;

    integer errors = 0;
    integer i;

    parity_gen uut (
        .in(in),
        .parity(parity),
        .out_frame(out_frame)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_parity_gen Testbench");
        $display("========================================");

        for (i = 0; i < 16; i = i + 1) begin
            in = i[3:0];
            #5;
            if (parity !== ^in || out_frame !== {in, ^in}) begin
                $display("ERROR: in=%b -> expected parity=%b, got %b", in, ^in, parity);
                errors = errors + 1;
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_parity_gen passed all 16 test vectors!");
        else
            $display("FAILURE: tb_parity_gen encountered %0d errors.", errors);
        $finish;
    end
endmodule
