// Testbench for 4-bit Binary Subtractor (subtractor4)
`timescale 1ns / 1ps

module tb_subtractor4;
    reg  [3:0] a;
    reg  [3:0] b;
    wire [3:0] diff;
    wire       borrow;

    integer errors = 0;
    integer i, j;
    reg [4:0] expected;

    subtractor4 uut (
        .a(a),
        .b(b),
        .diff(diff),
        .borrow(borrow)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_subtractor4 Testbench");
        $display("========================================");
        for (i = 0; i < 16; i = i + 1) begin
            for (j = 0; j < 16; j = j + 1) begin
                a = i[3:0];
                b = j[3:0];
                #5;
                expected = {1'b0, a} - {1'b0, b};
                if (diff !== expected[3:0] || borrow !== (a < b)) begin
                    $display("ERROR: a=%d b=%d -> expected diff=%d borrow=%b, got diff=%d borrow=%b",
                             a, b, expected[3:0], (a < b), diff, borrow);
                    errors = errors + 1;
                end
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_subtractor4 passed all 256 test vectors!");
        else
            $display("FAILURE: tb_subtractor4 encountered %0d errors.", errors);
        $finish;
    end
endmodule
