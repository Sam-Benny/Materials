// Testbench for 4-to-1 Multiplexer (mux4to1)
`timescale 1ns / 1ps

module tb_mux4to1;
    reg  [3:0] in_data;
    reg  [1:0] sel;
    wire       out_bit;

    integer errors = 0;
    integer i, s;

    mux4to1 uut (
        .in_data(in_data),
        .sel(sel),
        .out_bit(out_bit)
    );

    initial begin
        $display("========================================");
        $display("Starting tb_mux4to1 Testbench");
        $display("========================================");

        for (i = 0; i < 16; i = i + 1) begin
            for (s = 0; s < 4; s = s + 1) begin
                in_data = i[3:0];
                sel     = s[1:0];
                #5;
                if (out_bit !== in_data[sel]) begin
                    $display("ERROR: in_data=%b sel=%d -> expected %b, got %b",
                             in_data, sel, in_data[sel], out_bit);
                    errors = errors + 1;
                end
            end
        end

        if (errors == 0)
            $display("SUCCESS: tb_mux4to1 passed all 64 test vectors!");
        else
            $display("FAILURE: tb_mux4to1 encountered %0d errors.", errors);
        $finish;
    end
endmodule
