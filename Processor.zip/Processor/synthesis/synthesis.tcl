# Cadence Genus Synthesis Solution Script for SCL 180nm PDK
# Design: Educational Digital Processor (top_edu_processor)
# Clock: 20 MHz (50 ns period)

set LOCAL_DIR    "/home/user31/Sam/ASIC_Git/Processor"
set LOCAL_LIB    "/home/cadence/install_RB_8.7/FOUNDRY/scl180"
set SYNTH_DIR    "$LOCAL_DIR/synthesis/work"
set REPORTS_PATH "$LOCAL_DIR/synthesis/reports"
set LIB_PATH     "$LOCAL_LIB/scl180/stdcell/fs120/4M1IL/liberty/lib_flow_ff $LOCAL_LIB/scl180/stdcell/fs120/4M1IL/liberty/lib_flow_ss $LOCAL_LIB/scl180/iopad/cio150/4M1L/liberty $LOCAL_LIB/scl180/stdcell/fs120/4M1IL/lef $LOCAL_LIB/scl180/iopad/cio150/4M1L/lef"
set RTL_PATH     "$LOCAL_DIR/rtl $LOCAL_DIR/rtl/alu_modules"
set DESIGN       "top_edu_processor"

set LIB_LIST {tsl18fs120_scl_ff.lib tsl18fs120_scl_ss.lib tsl18cio150_max.lib tsl18cio150_min.lib}
set LEF_LIST {scl18fs120_tech.lef scl18fs120_std.lef tsl18cio150_4lm.lef tsl180l4.lef}

set RTL_LIST {
    top_edu_processor.v
    edu_processor_core.v
    edu_alu.v
    adder4.v
    subtractor4.v
    logic_unit.v
    encoder8to3.v
    decoder3to8.v
    mux4to1.v
    shifter8.v
    twos_complement8.v
    bin2gray.v
    parity_gen.v
    comparator4.v
    data_memory.v
}

set CAP_TABLE_FILE $LOCAL_LIB/scl180/stdcell/fs120/4M/generated_captable_4M.cap
set QRC_TECH_FILE  $LOCAL_LIB/scl180/stdcell/fs120/4M/qrcTechFile_4M

# Environment and Database Attributes
set_db hdl_track_filename_row_col true
set_db init_lib_search_path $LIB_PATH
set_db init_hdl_search_path $RTL_PATH
set_db error_on_lib_lef_pin_inconsistency true

set_db library $LIB_LIST
set_db lef_library $LEF_LIST

set_db cap_table_file $CAP_TABLE_FILE
set_db qrc_tech_file  $QRC_TECH_FILE

set_db syn_generic_effort high
set_db syn_map_effort     high
set_db syn_opt_effort     high
set_db auto_ungroup       none

puts "========================================================"
puts " Loading RTL Design Files for $DESIGN"
puts "========================================================"
read_hdl $RTL_LIST

puts "========================================================"
puts " Elaborating Design: $DESIGN"
puts "========================================================"
elaborate $DESIGN
check_design -all

puts "Runtime & Memory after read_hdl and elaboration:"
timestat Elaboration

puts "========================================================"
puts " Reading SDC Constraints (20 MHz / 50ns clock)"
puts "========================================================"
read_sdc constraints.sdc

puts "========================================================"
puts " Running Synthesis: Generic -> Mapping -> Optimization"
puts "========================================================"
syn_gen
syn_map
syn_opt

# Write Netlists and Outfiles
write_hdl > core_netlist.v
write_sdc > sdc.sdc
write_sdf > sdf.sdf

# Generate Comprehensive Reports
file mkdir $REPORTS_PATH
report_timing > $REPORTS_PATH/timing.rpt
report_gates  > $REPORTS_PATH/gates.rpt
report_area   > $REPORTS_PATH/area.rpt
report_power  > $REPORTS_PATH/power.rpt

write_do_lec -revised_design ./core_netlist.v > dofile
puts "Synthesis Completed Successfully for $DESIGN."
