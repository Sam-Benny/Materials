# Synopsys Design Constraints (SDC) for Educational Digital Processor
# Technology: SCL 180nm CMOS PDK (4 Metal Layers)
# Target Clock: 20 MHz (Period = 50.0 ns)

set sdc_version 2

set_units -time 1.0ns;
set_units -capacitance 1.0pF;

current_design top_edu_processor

# Parameterizable Clock Definition
set clk_period 50.0; # 20 MHz Target Clock Period
create_clock -name clk -period $clk_period [get_ports clk]

# Clock Slew and Transition Constraints
set_clock_transition -rise -min [expr $clk_period * 0.125] [get_clocks clk]
set_clock_transition -rise -max [expr $clk_period * 0.200] [get_clocks clk]
set_clock_transition -fall -min [expr $clk_period * 0.125] [get_clocks clk]
set_clock_transition -fall -max [expr $clk_period * 0.200] [get_clocks clk]

# Clock Uncertainty (Setup & Hold Jitter Margin)
set_clock_uncertainty -setup [expr $clk_period * 0.025] [get_clocks clk]
set_clock_uncertainty -hold  [expr $clk_period * 0.025] [get_clocks clk]

# Clock Network Latency
set_clock_latency -max 2.5 [get_ports clk]
set_clock_latency -min 0.5 [get_ports clk]

# Clock Source Latency
set_clock_latency -source -max 1.25 -late  [get_ports clk] [get_clock clk]
set_clock_latency -source -min 0.75 -late  [get_ports clk] [get_clock clk]
set_clock_latency -source -max 1.00 -early [get_ports clk] [get_clock clk]
set_clock_latency -source -min 1.25 -early [get_ports clk] [get_clock clk]

# Input / Output Port Collections
set INPUTPORTS [remove_from_collection [all_inputs] [get_ports clk]]

# Input Transition Constraints
set_input_transition -max 2.5 $INPUTPORTS
set_input_transition -min 1.0 $INPUTPORTS

# Input Delay (Relative to Clock)
set_input_delay -add_delay -clock clk -max 15.0 $INPUTPORTS
set_input_delay -add_delay -clock clk -min  5.0 $INPUTPORTS

# Output Delay Constraints
set_output_delay -clock clk -max 10.0 [all_outputs] -add_delay
set_output_delay -clock clk -min  4.0 [all_outputs] -add_delay

# Output Pin Capacitive Load (5 pF)
set_load 5.0 [all_outputs]

# Timing Path Groups for Optimization
group_path -name I2R -from [all_inputs]    -to [all_registers]
group_path -name R2O -from [all_registers] -to [all_outputs]
group_path -name R2R -from [all_registers] -to [all_registers]
group_path -name I2O -from [all_inputs]    -to [all_outputs]
